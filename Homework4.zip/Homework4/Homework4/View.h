//
//  View.h
//  Homework4
//
//  Created by Kathleen Urvalek on 7/21/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View : UIView {
    UIButton *button;
    
}

@end
