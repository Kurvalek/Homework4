//
//  View.m
//  Homework4
//
//  Created by Kathleen Urvalek on 7/21/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "View.h"


@implementation View

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        self.backgroundColor = [UIColor orangeColor];
        
        
        CGSize s = CGSizeMake(200, 40);	//size of button
		CGRect b = self.bounds;
		
		CGRect f = CGRectMake(
                              b.origin.x + (b.size.width - s.width) / 2,
                              b.origin.y + (b.size.height - s.height) / 2,
                              s.width,
                              s.height
                              );
		
		button = [UIButton buttonWithType: UIButtonTypeRoundedRect];
		[button retain];
		button.frame = f;
		
		[button setTitleColor: [UIColor blackColor]
                     forState: UIControlStateNormal];
		[button setTitle: @"THIS IS THE REMIX"
                forState: UIControlStateNormal];
		
		[button addTarget: [UIApplication sharedApplication].delegate
                   action: @selector(touchUpInside:)
         forControlEvents: UIControlEventTouchUpInside
         ];
		
		[self addSubview: button];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc
{
    [super dealloc];
}

@end
