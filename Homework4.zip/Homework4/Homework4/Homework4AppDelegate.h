//
//  Homework4AppDelegate.h
//  Homework4
//
//  Created by Kathleen Urvalek on 7/21/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AvFoundation/AVAudioPlayer.h>
@class View;

@interface Homework4AppDelegate : NSObject <UIApplicationDelegate> {
    MPMoviePlayerController *controller;
    AVAudioPlayer *player;
	View *view;
	UIWindow *window;

}

- (void) touchUpInside: (id) sender;

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
