//
//  Homework4Tests.m
//  Homework4Tests
//
//  Created by Kathleen Urvalek on 7/21/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "Homework4Tests.h"


@implementation Homework4Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Homework4Tests");
}

@end
