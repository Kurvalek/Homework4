//
//  Homework4Tests.h
//  Homework4Tests
//
//  Created by Kathleen Urvalek on 7/21/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface Homework4Tests : SenTestCase {
@private
    
}

@end
